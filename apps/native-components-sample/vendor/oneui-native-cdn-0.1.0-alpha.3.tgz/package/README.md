# @oneui/native-cdn

Brand-data delivery for OneUI **React Native**. Fetches each brand's `latest.json` from the CDN and feeds it to `<OneUIBrandProvider>` from `@oneui/ui-native`.

Two ways to use it — pick one (or combine):

| Mode | Data fetched | Command | Offline first launch |
| --- | --- | --- | --- |
| **A. Prefetch** | Before the bundler, baked into the app | `oneui-native-cdn prefetch` | ✅ |
| **B. Runtime** | On the device at app boot (OTA) | *(none — the hook fetches)* | ❌ (needs network once) |

---

## Install

```bash
npm install ./oneui-native-cdn-0.1.0-alpha.0.tgz

```

---

## The two payload shapes (read this first)

A sub-brand is **not** a standalone brand — it's an accent delta. The CDN serves two shapes, matching the provider's two props:

| File | Shape | Provider prop |
| --- | --- | --- |
| `<brand>/latest.json` | `{ foundation, components? }` → `BrandData` | `brandData` |
| `<brand>/sub-brands/<sub>/latest.json` | `{ themeData }` → `ThemeData` | `themeData` |

To render a sub-brand you pass the **parent's** `brandData` **plus** the sub-brand's `themeData`; the provider merges them. For a plain parent brand, omit `themeData`.

---

## Mode A — Prefetch (recommended)

### 1. Create `oneui.brands.json` in the app root

```json
{
  "cdnUrl": "https://myjiostatic.cdn.jio.com/JDS/ReactNative",
  "brands": {
    "jio":  { "subBrands": ["jiomart"] },
    "tira": "latest"
  }
}
```

`cdnUrl` is the base **up to (not including) `brand-data`** — the plugin appends `/brand-data/<brand>/latest.json`. So the config above fetches:

- `…/brand-data/tira/latest.json`
- `…/brand-data/jio/latest.json` **and** `…/brand-data/jio/sub-brands/jiomart/latest.json`

| Field | Required | Description |
| --- | --- | --- |
| `cdnUrl` | yes* | CDN base up to (not including) `brand-data`. |
| `brands.<slug>` | yes | `"latest"` (parent only) or `{ version?, subBrands? }`. |
| `…version` | no | File stem to fetch. Default `"latest"`. |
| `…subBrands` | no | Sub-brand slugs to also fetch as `themeData` deltas. |

\* `cdnUrl` may instead come from `--cdn-url` or the `ONEUI_CDN_URL` env var. `brands` must live in this file.

### 2. Run the prefetch

```bash
npx oneui-native-cdn prefetch
```

```
[@oneui/native-cdn] prefetching brand-data → .oneui-cached
  ✓ tira/latest.json
  ✓ jio/latest.json
    ✓ jio/sub-brands/jiomart/latest.json
[@oneui/native-cdn] 3/3 variant(s) ready → manifest .oneui-cached/index.ts
```

It writes JSON + a generated manifest into `.oneui-cached/` (self-ignoring, never committed). Run it before every start by wiring it into your scripts:

```jsonc
// package.json
"scripts": {
  "start": "oneui-native-cdn prefetch && expo start",
  "ios":   "oneui-native-cdn prefetch && expo start --ios"
}
```

### 3. Use the bundled data

Import the **synchronous accessors** the prefetch generated into `./.oneui-cached` — the data is already baked into the bundle, so there's no fetch and no loading state. (The `useCdnBrandData` hook is **only** for Mode B, where the device fetches at runtime.)

```tsx
import { OneUIBrandProvider } from '@oneui/ui-native';
import { getCdnBrandData, getCdnThemeData } from './.oneui-cached';

export default function App() {
  const brandData = getCdnBrandData('jio');             // parent { foundation, components }
  const themeData = getCdnThemeData('jio', 'jiomart');  // sub-brand delta (undefined for parent)

  return (
    <OneUIBrandProvider brandData={brandData} themeData={themeData} themeMode="light">
      {/* your app */}
    </OneUIBrandProvider>
  );
}
```

---

## Mode B — Runtime fetch (OTA, no command)

No prefetch and no `oneui.brands.json` — configure the CDN in code; the device fetches on boot, caches, and revalidates in the background.

```tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { OneUICdnProvider, useCdnBrandData, createAsyncStorageCache } from '@oneui/native-cdn';
import { OneUIBrandProvider } from '@oneui/ui-native';

function Root() {
  return (
    <OneUICdnProvider
      cdnUrl="https://myjiostatic.cdn.jio.com/JDS/ReactNative"
      storage={createAsyncStorageCache(AsyncStorage)}  // omit for in-memory (no cold-start persistence)
    >
      <Themed />
    </OneUICdnProvider>
  );
}

function Themed() {
  // A sub-brand variant fetches BOTH the parent brandData and the sub-brand themeData.
  const { brandData, themeData, status, error } = useCdnBrandData('jio', 'jiomart');

  if (status === 'error') return <ErrorView error={error} />;

  return (
    <OneUIBrandProvider brandData={brandData} themeData={themeData} themeMode="light" loadingFallback={<Spinner />}>
      {/* your app */}
    </OneUIBrandProvider>
  );
}
```

Then just `npx expo start` — the hook fetches on launch.

**`useCdnBrandData(brand, variant?, options?)`** returns:

| Field | Meaning |
| --- | --- |
| `brandData` | `BrandData \| undefined` → `<OneUIBrandProvider brandData={…}>` |
| `themeData` | `ThemeData \| null` → `<OneUIBrandProvider themeData={…}>` |
| `status` | `'loading' \| 'success' \| 'error'` |
| `source` | `'cache' \| 'network' \| undefined` |
| `error` | latest failure (set even while cache is shown) |
| `refetch()` | force a fresh revalidation |

Options: `cdnUrl`, `version` (`'latest'`), `storage`, `cachePrefix` (`'oneui-cdn:'`), `revalidate` (`true`), `enabled` (`true`).

> **Hybrid (A + B):** prefetch a default for instant paint, then mount `useCdnBrandData` to pull fresh JSON over the air.

### Cache adapters (Mode B)

| Adapter | Use when |
| --- | --- |
| `createMemoryStorage()` *(default)* | dev (no cold-start persistence) |
| `createAsyncStorageCache(AsyncStorage)` | most apps (Expo + bare CLI) |
| `createFileSystemCache(backend)` | Expo apps without AsyncStorage (`expo-file-system` / `react-native-fs`) |

---

## CLI reference

```
oneui-native-cdn prefetch [options]
```

| Flag | Default | Description |
| --- | --- | --- |
| `--cdn-url <url>` | config / `ONEUI_CDN_URL` | CDN base (overrides config). |
| `--config <file>` | `oneui.brands.json` | Brand config path. |
| `--cache-dir <dir>` | `.oneui-cached` | Output directory. |
| `--out <file>` | `<cache-dir>/index.ts` | Generated manifest path. |
| `--offline` | off | Skip the network; use cache only. |

**Resilience:** `404` → skip that brand (stale cache removed); `5xx` / network error → reuse cache with a warning; never throws, so a transient outage won't break `expo start`.

Programmatic API: `import { prefetchBrandData } from '@oneui/native-cdn/prefetch'`.

---

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| `cdnUrl not set` | Add `cdnUrl` to `oneui.brands.json`, pass `--cdn-url`, or set `ONEUI_CDN_URL`. |
| `no brands configured` | Add a `brands` map to `oneui.brands.json` (can't be a flag). |
| `command not found: oneui-native-cdn` | Run via `npx oneui-native-cdn prefetch`. |
| Import of `./.oneui-cached` fails | RN ≥ 0.79, or set `unstable_enablePackageExports = true` in `metro.config.js`. |
| `✗ <brand>/latest.json` in output | URL 404'd or wasn't valid JSON — check the slug and that `cdnUrl` resolves to a real `latest.json`. |
| Peer dependency conflicts | Align `react` to `^18.3 || ^19`, or install with `--legacy-peer-deps`. |
