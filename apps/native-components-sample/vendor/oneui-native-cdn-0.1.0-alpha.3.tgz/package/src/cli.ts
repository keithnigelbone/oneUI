#!/usr/bin/env node
/**
 * CLI for @oneui/native-cdn build-time prefetch.
 *
 *   oneui-native-cdn prefetch [--cdn-url <url>] [--config <file>]
 *                             [--cache-dir <dir>] [--out <manifest.ts>] [--offline]
 *
 * Typically wired ahead of the bundler:
 *
 *   "dev": "oneui-native-cdn prefetch && expo start"
 */

import { prefetchBrandData, type PrefetchOptions } from './prefetch';

function parseArgs(argv: string[]): PrefetchOptions & { _command?: string } {
  const out: PrefetchOptions & { _command?: string } = {};
  const flag: Record<string, keyof PrefetchOptions> = {
    '--cdn-url': 'cdnUrl',
    '--config': 'configFile',
    '--cache-dir': 'cacheDir',
    '--out': 'manifestFile',
  };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--offline') {
      out.offline = true;
    } else if (arg in flag) {
      const value = argv[++i];
      if (value === undefined) throw new Error(`[@oneui/native-cdn] missing value for ${arg}`);
      (out as Record<string, unknown>)[flag[arg]] = value;
    } else if (!arg.startsWith('-') && !out._command) {
      out._command = arg; // e.g. "prefetch"
    } else {
      throw new Error(`[@oneui/native-cdn] unknown argument: ${arg}`);
    }
  }
  return out;
}

async function main(): Promise<void> {
  const { _command, ...options } = parseArgs(process.argv.slice(2));
  if (_command && _command !== 'prefetch') {
    throw new Error(`[@oneui/native-cdn] unknown command "${_command}". Did you mean "prefetch"?`);
  }
  await prefetchBrandData(options);
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
