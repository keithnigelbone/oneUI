/**
 * Build-time brand-data prefetch for @oneui/native-cdn — the React Native
 * counterpart of `@oneui/vite-plugin`'s `syncCache`.
 *
 * Metro has no virtual-module / `load()` hook, so (unlike Vite) it can't read a
 * cache folder and synthesise modules from it at build time. The cached JSON
 * only reaches the device if it's a REAL file Metro can statically import.
 * So this step does two things:
 *
 *   1. Fetch each brand's `latest.json` from the CDN and write it into
 *      `.oneui-cached/brand-data/<brand>/…` (mirrors the CDN path layout).
 *   2. Generate a real `.ts` manifest that statically imports those JSON files
 *      and exposes `getCdnBrandData(brand, variant)` — Metro bundles it, the
 *      app imports it, zero runtime network needed for first paint.
 *
 * Run it before the bundler, e.g. in package.json:
 *
 *   "dev": "oneui-native-cdn prefetch && expo start"
 *
 * Config (default `oneui.brands.json`, same shape as the web plugin):
 *
 *   {
 *     "cdnUrl": "https://myjiostatic.cdn.jio.com/JDS/ReactNative",
 *     "brands": {
 *       "jio":  { "subBrands": ["jiomart"] },
 *       "tira": "latest"
 *     }
 *   }
 *
 * Sync policy mirrors the web plugin: force-fetch each build; on 404 the stale
 * cache file is deleted and the brand is skipped; on 5xx / network error the
 * existing cache file is reused (with a warning); `offline: true` skips the
 * network entirely. The prefetch NEVER throws on a fetch failure — a transient
 * outage must not break `expo start`.
 */

import {
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  writeFileSync,
} from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { resolveBrandUrl } from './urls';

/** Per-brand entry in `oneui.brands.json` — string version or object with sub-brands. */
export type BrandConfigEntry = string | { version?: string; subBrands?: string[] };

export interface PrefetchLogger {
  info(message: string): void;
  warn(message: string): void;
}

export interface PrefetchOptions {
  /** CDN base up to (not including) `brand-data`. Falls back to env `ONEUI_CDN_URL` then config file. */
  cdnUrl?: string;
  /** Brand slug → version or `{ version, subBrands }`. Falls back to config file. */
  brands?: Record<string, BrandConfigEntry>;
  /** Brand config file, relative to `projectRoot`. Default `oneui.brands.json`. */
  configFile?: string;
  /** Project root. Default `process.cwd()`. */
  projectRoot?: string;
  /**
   * Cache directory. Default: `node_modules/oneui-cached` (relative to `projectRoot`).
   * Brand JSON files land in `<cacheDir>/brand-data/` and the manifest at
   * `<cacheDir>/index.ts`, making it importable as `'oneui-cached'` by Metro.
   */
  cacheDir?: string;
  /** Generated manifest path, relative to `projectRoot`. Default `<cacheDir>/index.ts`. */
  manifestFile?: string;
  /** Skip the network; use whatever is already cached. Default `false`. */
  offline?: boolean;
  /** Defaults to `console`. */
  logger?: PrefetchLogger;
}

export interface PrefetchVariantResult {
  brand: string;
  variant: string;
  /** `true` when a JSON file is present on disk after this run. */
  ok: boolean;
  bytes: number;
}

export interface PrefetchResult {
  variants: PrefetchVariantResult[];
  cacheDir: string;
  manifestFile: string;
}

interface ResolvedEntry {
  version: string;
  subBrands: string[];
}

interface ResolvedOptions {
  cdnUrl: string;
  brands: Record<string, ResolvedEntry>;
  cacheDir: string;
  manifestFile: string;
  offline: boolean;
  logger: PrefetchLogger;
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function readJSON<T>(file: string): T | null {
  if (!existsSync(file)) return null;
  try {
    return JSON.parse(readFileSync(file, 'utf8')) as T;
  } catch {
    return null;
  }
}

function ensureDir(dir: string): void {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

function normalizeEntry(raw: BrandConfigEntry): ResolvedEntry {
  if (typeof raw === 'string') return { version: raw || 'latest', subBrands: [] };
  return {
    version: raw.version ?? 'latest',
    subBrands: Array.isArray(raw.subBrands) ? [...raw.subBrands] : [],
  };
}

function resolveOptions(opts: PrefetchOptions): ResolvedOptions {
  const projectRoot = opts.projectRoot ?? process.cwd();
  const configPath = resolve(projectRoot, opts.configFile ?? 'oneui.brands.json');
  const fileCfg = readJSON<{ cdnUrl?: string; brands?: Record<string, BrandConfigEntry> }>(configPath);

  const cdnUrl = opts.cdnUrl ?? process.env.ONEUI_CDN_URL ?? fileCfg?.cdnUrl ?? '';
  if (!cdnUrl) {
    throw new Error(
      `[@oneui/native-cdn] cdnUrl not set. Pass it inline, set ONEUI_CDN_URL, or add it to ${configPath}.`,
    );
  }

  const rawBrands = opts.brands ?? fileCfg?.brands ?? {};
  if (Object.keys(rawBrands).length === 0) {
    throw new Error(
      `[@oneui/native-cdn] no brands configured. Pass { brands } or list them in ${configPath}.`,
    );
  }

  const brands: Record<string, ResolvedEntry> = {};
  for (const [slug, entry] of Object.entries(rawBrands)) brands[slug] = normalizeEntry(entry);

  const cacheDir = opts.cacheDir
    ? resolve(projectRoot, opts.cacheDir)
    : resolve(projectRoot, 'node_modules', '.oneui-cached');
  return {
    cdnUrl,
    brands,
    cacheDir,
    manifestFile: resolve(projectRoot, opts.manifestFile ?? join(cacheDir, 'index.ts')),
    offline: opts.offline ?? false,
    logger: opts.logger ?? console,
  };
}

// ─── Local cache paths (mirror the CDN layout) ───────────────────────────────

function brandDataRoot(cacheDir: string): string {
  return join(cacheDir, 'brand-data');
}
function brandJsonPath(cacheDir: string, brand: string): string {
  return join(brandDataRoot(cacheDir), brand, 'latest.json');
}
function subBrandJsonPath(cacheDir: string, brand: string, sub: string): string {
  return join(brandDataRoot(cacheDir), brand, 'sub-brands', sub, 'latest.json');
}

/**
 * Write a minimal `package.json` inside `cacheDir` so that Metro (and any
 * Node-compliant resolver) treats `oneui-cached` as a valid importable package.
 * Always overwritten so the `main` field stays correct after a re-prefetch.
 */
function writePackageJson(cacheDir: string): void {
  ensureDir(cacheDir);
  const pkg = {
    name: '.oneui-cached',
    version: '0.0.0',
    private: true,
    main: './index.ts',
    types: './index.ts',
    'react-native': './index.ts',
  };
  writeFileSync(join(cacheDir, 'package.json'), JSON.stringify(pkg, null, 2) + '\n');
}

/** Drop brand / sub-brand folders no longer present in the config. */
function pruneOrphans(r: ResolvedOptions): void {
  const root = brandDataRoot(r.cacheDir);
  if (!existsSync(root)) return;
  const wanted = new Set(Object.keys(r.brands));
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    if (!wanted.has(entry.name)) {
      try {
        rmSync(join(root, entry.name), { recursive: true, force: true });
        r.logger.info(`  ✗ pruned ${entry.name} (not in config)`);
      } catch {
        /* best effort */
      }
      continue;
    }
    const subRoot = join(root, entry.name, 'sub-brands');
    if (!existsSync(subRoot)) continue;
    const wantedSubs = new Set(r.brands[entry.name].subBrands);
    for (const subEntry of readdirSync(subRoot, { withFileTypes: true })) {
      if (!subEntry.isDirectory() || wantedSubs.has(subEntry.name)) continue;
      try {
        rmSync(join(subRoot, subEntry.name), { recursive: true, force: true });
        r.logger.info(`  ✗ pruned ${entry.name}/${subEntry.name} (not in config)`);
      } catch {
        /* best effort */
      }
    }
  }
}

// ─── Fetch one JSON, with cache fallback ─────────────────────────────────────

/** Parent files carry `foundation`; sub-brand files carry `themeData`. */
function hasKey(text: string, key: 'foundation' | 'themeData'): boolean {
  try {
    const parsed: unknown = JSON.parse(text);
    return typeof parsed === 'object' && parsed !== null && key in parsed;
  } catch {
    return false;
  }
}

/**
 * Returns the JSON text to persist, or `null` when unavailable. Never throws.
 * 404 → delete stale cache + skip; 5xx / network / invalid → reuse cache if any.
 */
async function fetchJsonText(
  url: string,
  cacheFile: string,
  expectKey: 'foundation' | 'themeData',
  r: ResolvedOptions,
): Promise<string | null> {
  if (r.offline) {
    if (existsSync(cacheFile)) return readFileSync(cacheFile, 'utf8');
    r.logger.warn(`[@oneui/native-cdn] offline: no cache for ${url}`);
    return null;
  }

  try {
    const res = await fetch(url);
    if (res.status === 404) {
      if (existsSync(cacheFile)) rmSync(cacheFile, { force: true });
      r.logger.warn(`[@oneui/native-cdn] ${url} → 404 (absent on CDN); skipped`);
      return null;
    }
    if (!res.ok) {
      r.logger.warn(
        `[@oneui/native-cdn] ${url} → HTTP ${res.status}; ${existsSync(cacheFile) ? 'using cache' : 'skipped'}`,
      );
    } else {
      const text = await res.text();
      if (hasKey(text, expectKey)) return text;
      r.logger.warn(
        `[@oneui/native-cdn] ${url} missing "${expectKey}"; ${existsSync(cacheFile) ? 'using cache' : 'skipped'}`,
      );
    }
  } catch (e) {
    r.logger.warn(
      `[@oneui/native-cdn] ${url} fetch failed: ${(e as Error).message}; ${existsSync(cacheFile) ? 'using cache' : 'skipped'}`,
    );
  }

  return existsSync(cacheFile) ? readFileSync(cacheFile, 'utf8') : null;
}

// ─── Manifest generation ─────────────────────────────────────────────────────

function importIdentifier(brand: string, variant: string): string {
  const safe = (s: string) => s.replace(/[^a-zA-Z0-9]/g, '_');
  return `brand_${safe(brand)}_${safe(variant)}`;
}

interface PresentEntry {
  brand: string;
  variant: string;
  /** `'brand'` = parent ({ foundation, components }); `'theme'` = sub-brand ({ themeData }). */
  kind: 'brand' | 'theme';
  file: string;
}

function generateManifest(r: ResolvedOptions, present: PresentEntry[]): void {
  const dir = dirname(r.manifestFile);
  const importLine = (importName: string, file: string): string => {
    const rel = relative(dir, file).split(sep).join('/');
    return `import ${importName} from '${rel.startsWith('.') ? rel : `./${rel}`}';`;
  };

  const rows = [...present]
    .sort((a, b) => `${a.brand}::${a.variant}`.localeCompare(`${b.brand}::${b.variant}`))
    .map((e) => ({ ...e, importName: importIdentifier(e.brand, e.variant) }));

  const parents = rows.filter((e) => e.kind === 'brand');
  const subs = rows.filter((e) => e.kind === 'theme');

  const lines = [
    '/** AUTO-GENERATED by `oneui-native-cdn prefetch` — do not edit. */',
    "import type { BrandData, ThemeData } from '@oneui/ui-native';",
    '',
    '// Parent-brand snapshots — { foundation, components }',
    ...parents.map((e) => importLine(e.importName, e.file)),
    ...(subs.length ? ['', '// Sub-brand accent deltas — { themeData }'] : []),
    ...subs.map((e) => importLine(e.importName, e.file)),
    '',
    '/** Parent-brand data keyed by brand slug. Read by OneUIBrandProvider\'s cachedManifest. */',
    'export const CDN_BRAND_DATA: Record<string, BrandData> = {',
    ...parents.map((e) => `  '${e.brand}': ${e.importName} as BrandData,`),
    '};',
    '',
    '/** Sub-brand accent deltas keyed by `"brand::variant"`. Read by OneUIBrandProvider\'s cachedManifest. */',
    'export const CDN_THEME_DATA: Record<string, ThemeData> = {',
    ...subs.map(
      (e) => `  '${e.brand}::${e.variant}': (${e.importName} as { themeData: ThemeData }).themeData,`,
    ),
    '};',
    '',
    '/** Every prefetched (brand, variant) pair. `variant` is `"base"` for the parent. */',
    'export const CDN_BRANDS: ReadonlyArray<{ brand: string; variant: string }> = [',
    ...rows
      .filter((e) => e.kind === 'brand')
      .map((e) => `  { brand: '${e.brand}', variant: 'base' },`),
    ...subs.map((e) => `  { brand: '${e.brand}', variant: '${e.variant}' },`),
    '];',
    '',
    '/** Parent-brand snapshot — pass to `<OneUIBrandProvider brandData={…}>`. */',
    'export function getCdnBrandData(brand: string): BrandData | undefined {',
    '  return CDN_BRAND_DATA[brand];',
    '}',
    '',
    '/** Sub-brand accent delta — pass to `<OneUIBrandProvider themeData={…}>`. `undefined` for the parent. */',
    "export function getCdnThemeData(brand: string, variant = 'base'): ThemeData | undefined {",
    "  if (!variant || variant === 'base') return undefined;",
    '  return CDN_THEME_DATA[`${brand}::${variant}`];',
    '}',
    '',
  ];

  ensureDir(dir);
  writeFileSync(r.manifestFile, lines.join('\n'));
}

// ─── Entry point ─────────────────────────────────────────────────────────────

export async function prefetchBrandData(opts: PrefetchOptions = {}): Promise<PrefetchResult> {
  const r = resolveOptions(opts);
  ensureDir(brandDataRoot(r.cacheDir));
  writePackageJson(r.cacheDir);
  pruneOrphans(r);

  r.logger.info(
    `[@oneui/native-cdn] prefetching brand-data → ${relative(process.cwd(), r.cacheDir) || r.cacheDir}${r.offline ? ' (offline)' : ''}`,
  );

  const variants: PrefetchVariantResult[] = [];
  const present: PresentEntry[] = [];

  for (const [brand, entry] of Object.entries(r.brands)) {
    // Parent brand — { foundation, components }
    const parentFile = brandJsonPath(r.cacheDir, brand);
    const parentText = await fetchJsonText(
      resolveBrandUrl(r.cdnUrl, brand, undefined, entry.version),
      parentFile,
      'foundation',
      r,
    );
    if (parentText) {
      ensureDir(dirname(parentFile));
      writeFileSync(parentFile, parentText);
      present.push({ brand, variant: 'base', kind: 'brand', file: parentFile });
    }
    variants.push({ brand, variant: 'base', ok: !!parentText, bytes: parentText ? Buffer.byteLength(parentText) : 0 });
    r.logger.info(`  ${parentText ? '✓' : '✗'} ${brand}/latest.json`);

    // Sub-brands — { themeData }
    for (const sub of entry.subBrands) {
      const subFile = subBrandJsonPath(r.cacheDir, brand, sub);
      const subText = await fetchJsonText(
        resolveBrandUrl(r.cdnUrl, brand, sub, entry.version),
        subFile,
        'themeData',
        r,
      );
      if (subText) {
        ensureDir(dirname(subFile));
        writeFileSync(subFile, subText);
        present.push({ brand, variant: sub, kind: 'theme', file: subFile });
      }
      variants.push({ brand, variant: sub, ok: !!subText, bytes: subText ? Buffer.byteLength(subText) : 0 });
      r.logger.info(`    ${subText ? '✓' : '✗'} ${brand}/sub-brands/${sub}/latest.json`);
    }
  }

  generateManifest(r, present);

  const ok = variants.filter((v) => v.ok).length;
  r.logger.info(
    `[@oneui/native-cdn] ${ok}/${variants.length} variant(s) ready → manifest ${relative(process.cwd(), r.manifestFile) || r.manifestFile}`,
  );

  return { variants, cacheDir: r.cacheDir, manifestFile: r.manifestFile };
}
